# SOAL 4

# C(7,4) = 7! / 4! (7 - 4)!
#        = 7! / 4! * 3!

# 7! = 7*6*5*4!
# 4! = 4*3*2! = 24
# 3! = 3*2!   = 6

# C(7,4) =

Vaktorial_7 = 7*6*5
Vaktorial_3 = 3*2

Hasil_Vaktorial =int(Vaktorial_7 / Vaktorial_3)

print("Jadi, ada ", Hasil_Vaktorial ,"cara untuk membantu Darsono membentuk sebuah tim")
