# SOAL 3
Dolar = 35
# Jumlah rupiah ditanggal 25 september 2024
Rupiah = 15.110

print("Nominal uang yang didapatkan oleh Suraji adalah")
Nominal_uang_yang_didapat = (Dolar*Rupiah)
print(Nominal_uang_yang_didapat)
