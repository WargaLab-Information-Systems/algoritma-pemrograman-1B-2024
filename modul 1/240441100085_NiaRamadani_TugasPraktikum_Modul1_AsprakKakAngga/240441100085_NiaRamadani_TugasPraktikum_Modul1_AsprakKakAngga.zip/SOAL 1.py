# SOAL 1
# DATA CELENGAN BALOK
Panjang =20  #cm
Lebar = 13   #cm
Tinggi = 7   #cm

print("volume celengan balok milik Andi adalah")
Volume = Panjang * Lebar * Tinggi
print(Volume)


# DATA CELENGAN TABUNG
Diameter = 14       #cm
Luas_Selimut = 440  #cm

print("volume celengan tabung milik Andi adalah")
r =int(Diameter / 2)
phi = 22/7
Tinggi_tabung = int(Luas_Selimut/(2*phi*r))
Volume = int(phi * r * r * Tinggi_tabung)
print(Volume)









