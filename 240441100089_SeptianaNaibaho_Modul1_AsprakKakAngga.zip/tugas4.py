
n= int(input("masukkan total oraang :"))
r= int(input("masukkan jumlah orang yanng ingin dipilih :"))

faktorial_7 = 7*6*5*4*3*2*1
faktorial_4 = 4*3*2*1
faktorial_3 = 3*2*1

n_kombinasi_r= faktorial_7//(faktorial_4*faktorial_3)
print(f"jumlah cara untuk membentuk tim adalah : {n_kombinasi_r}")


