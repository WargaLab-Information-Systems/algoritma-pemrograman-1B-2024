#menghitung uang dari usd ke idr
#kurs tanggal 25 September 2024 = 15.124,85
usd= int(input("masukkan usd dollar :"))
kurs= float(input("masukkan kurs tanggal 25 September 2024 :"))

hasil= kurs*usd
print(f"hasil dollar ke rupiah adalah : {hasil} ")

